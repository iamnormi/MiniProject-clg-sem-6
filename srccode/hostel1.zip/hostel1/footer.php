
<div class="foot">

<p> <a class="pull-right" href="https://www.facebook.com/Raselhossain120"target="_blank">Md.Rasel Hossain</a></br>
<a class="pull-right" href="https://www.facebook.com/hossain22215"target="_blank">Abul Hossain </a></p>

<style> .foot{text-align:center; border: 2px solid black;}</style>

</div>