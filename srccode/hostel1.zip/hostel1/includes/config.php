<?php
$dbuser="root";
$dbpass="";
$host="localhost";
$db="hostel1";
$mysqli =new mysqli($host,$dbuser, $dbpass, $db);
?>